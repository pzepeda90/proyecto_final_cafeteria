const a="https://proyecto-final-cafeteria.onrender.com/api/api";export{a as A};
